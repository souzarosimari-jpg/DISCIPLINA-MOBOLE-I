import React from 'react'

const FuncoesProps = (props) => {
  return (
   <div>
    <h2>Terceiro Componente</h2>
    <p>Me chamo{props.nome}</p>
    <P>Sou Aluno do {props.curso}</P>
      <h3>Uso da Funçao Props</h3>
      <p>Olá {props.nome}</p>
      <p>Aluno de {props.descricao}</p>
    </div>
  )
}

export default FuncoesProps