import React from 'react'

const Contatos = () => {
  return (
    <div className="contatos">
      <h2>Meus Contatos</h2>

      <a href="tel:+5543988054339" classname="telefone">
      ☎ Telefone
      </a>

    <a href="mailto: souza.rosimari@escola.pr.gov.br" className="email">
    ✉ E-mail
    </a>

    <a href="https://wa.me/5543988054339" className="whatsapp"></a>
    📞 WhatsApp
    </div>

  )

}

export default Contatos