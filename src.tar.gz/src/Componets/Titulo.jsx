import React from 'react'

const Titulo = () => {
  return (
    <div>
      <img className='foto' src="https://github.com/ddgouvea/Img/blob/main/Portifolio/Programador.png?raw=true" alt="" />
      <h1>ROSY LOIRA</h1>
      <p className="profissao">Desenvonvedora Mobile</p>
      <p className="descricao">Atuo na criação e manutenção de aplicativos para smartphones, unindo habilidades técnicas em programação com foco em usabilidade, desempenho e resolução prática de problemas do dia a dia dos usuários.</p>
    </div>
  )}

export default Titulo